/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wolf3d.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nhendric <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/05 14:22:03 by nhendric          #+#    #+#             */
/*   Updated: 2018/09/17 13:59:24 by nhendric         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WOLF3D_H
# define WOLF3D_H

# include <math.h>
# include <mlx.h>
# include <stdlib.h>
# include <fcntl.h>
# include <unistd.h>
# include "libft.h"
# include "get_next_line.h"

typedef struct	s_env
{
	void		*mlx;
	void		*win;

	char		*map_name;
	char		**map;
	int			**arr;
	void		*img_ptr;
	
	int			*data;
	int			size_l;
	int			bpp;
	int			endian;

	int			x;
	int			y;
	double		h;
	double		w;

	double		posx;
	double		posy;
	double		dirx;
	double		diry;

	int			move_forward;
	double		movespeed;
	int			rotate_clockwise;
	double		rotspeed;

	double		planex;
	double		planey;
	double		raydirx;
	double		raydiry;
	int			mapx;
	int			mapy;
	double		sidedistx;
	double		sidedisty;
	double		deltadistx;
	double		deltadisty;
	double		perpwalldist;
	
	int			stepx;
	int			stepy;

	int			hit;
	int			side;

	int			line_color;
	int			lineheight;
	int			drawstart;
	int			drawend;
}				t_env;


int				expose_hook(t_env *z);
void			rotate(t_env *z);
void			move(t_env *z);

int				keyFunction(int keycode, t_env *z);
int				finished(t_env *z);
void			init(t_env *z);

void			render(t_env *z);
void			init_ray(t_env *z);
void			rayCheck(t_env *z);
void			collision(t_env *z);
void			colour_pick(t_env *z);

void			read_map(t_env *z);
void			convert(t_env *z);

#endif
