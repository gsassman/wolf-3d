/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nhendric <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/03 12:56:27 by nhendric          #+#    #+#             */
/*   Updated: 2020/01/06 13:22:57 by nhendric         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"
#include "stdio.h"

int		finished(t_env *z)
{
	mlx_destroy_window(z->mlx, z->win);
	exit(0);
	return (0);
}

void	init(t_env *z)
{
	z->h = 720;
	z->w = 1080;
	z->posx = 22;
	z->posy = 12;
	z->dirx = -1;
	z->diry = 0;
	z->planex = 0;
	z->planey = 0.66;
	z->movespeed = 0.4;
	z->rotspeed = 0.2;

	read_map(z);
	z->mlx = mlx_init();
	z->win = mlx_new_window(z->mlx, z->w, z->h, "WOLF3Dish...");
	z->img_ptr = mlx_new_image(z->mlx, z->w, z->h);
	z->data = (int *)mlx_get_data_addr(z->img_ptr, &z->bpp,
			&z->size_l, &z->endian);
}

int		keyFunction(int keycode, t_env *z)
{
	if (keycode == 53)
	{
		mlx_destroy_window(z->mlx, z->win);
		exit(0);
	}
	if (keycode == 124){
		z->rotate_clockwise = 1;
		rotate(z);
	} else if (keycode == 123){
		z->rotate_clockwise = 0;
		rotate(z);
	}
	if (keycode == 125) {
	   z->move_forward = 0;
		move(z);
	} else if (keycode == 126){
		z->move_forward = 1;
		move(z);
	}
	return (0);
}

int		main(int argc, char **argv)
{	
	t_env	*z = (t_env *)malloc(sizeof(t_env));

	if (argc == 2)
	{
		z->map_name = argv[1];
		init(z);
		render(z);
		mlx_put_image_to_window(z->mlx, z->win, z->img_ptr, 0, 0);
		mlx_hook(z->win, 2, 0, keyFunction, z);
		mlx_hook(z->win, 17, 0, finished, z);
		mlx_key_hook(z->win, keyFunction, z);
		mlx_loop(z->mlx);
	}
	else
		printf("that's not allowed");
	free(z);
	return (0);
	
}