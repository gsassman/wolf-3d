/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nhendric <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/08 12:30:24 by nhendric          #+#    #+#             */
/*   Updated: 2020/02/08 12:30:24 by nhendric         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

void	read_map(t_env *z)
{
	int		fd;
	char	*line;
	char	**map;
	int		k;

	k = 0;
	map = (char **)malloc(sizeof(char *) * 25);
	fd = open(z->map_name, O_RDONLY, 1);
	while (get_next_line(fd, &line))
	{
		map[k] = line;
		map[k][ft_strlen(line)] = '\0';
		k++;
	}
	map[k] = NULL;
	close(fd);
	free(line);
	z->map = map;
	convert(z);
}

void		convert(t_env *z)
{
	int		i;
	int		j;
	int		k;
	int		**tab;
	char	**arr;
	int		map_h = 24;

	k = 0;
	tab = (int **)malloc(sizeof(int *) * map_h);
	while (k < map_h)
	{
		i = 0;
		arr = ft_strsplit(z->map[k], ' ');
		j = map_h;
		tab[k] = (int *)malloc(sizeof(int) * j);
		while (i < j)
		{
			tab[k][i] = ft_atoi(arr[i]);
			free(arr[i]);
			i++;
		}
		free(arr);
		k++;
	}
	z->arr = tab;
}
